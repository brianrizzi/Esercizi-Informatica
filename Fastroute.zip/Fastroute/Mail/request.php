<?php

use PHPMailer\PHPMailer\PHPMailer;
use PHPMailer\PHPMailer\Exception;

require_once __DIR__ . '/../vendor/autoload.php';

if ($_SERVER["REQUEST_METHOD"] == "POST") {
    $nome = $_POST["nome"];
    $email = $_POST["email"];
    $messaggio = $_POST["messaggio"];

    try {
        $mail = new PHPMailer(true);
        $mail->isSMTP();
        $mail->Host = 'smtp.gmail.com';
        $mail->SMTPAuth = true;
        $mail->Username = 'brian.rizzi@iisviolamarchesini.edu.it';
        $mail->Password = '';
        $mail->SMTPSecure = PHPMailer::ENCRYPTION_STARTTLS;
        $mail->Port = 587;

        // Semplificazione configurazione mail
        $mail->setFrom('brian.rizzi@iisviolamarchesini.edu.it', 'FastRoute Info');
        $mail->addReplyTo($email, $nome);
        $mail->addAddress('brian.rizzi@iisviolamarchesini.edu.it', 'FastRoute');
        $mail->Subject = 'Richiesta informazioni';
        $mail->Body = "Nome: $nome\nEmail: $email\nMessaggio: $messaggio";

        $mail->send();
        $success = true;
    } catch (Exception $e){
        $error_message = "Errore nell'invio";
    }
}
