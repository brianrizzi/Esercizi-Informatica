<?php
// File: Mail/send.php

use PHPMailer\PHPMailer\PHPMailer;
use PHPMailer\PHPMailer\Exception;

require_once __DIR__ . '/../vendor/autoload.php';

function sendEmailNotification($cd_plico) {
    require_once __DIR__ . '/../Database/Db_connection.php';
    $config = require __DIR__ . '/../Database/db_config.php';
    $db = Db_connection::getDb($config);

    $query = "SELECT c.email, c.nome, c.cognome 
              FROM fastroute_f.spedizioni s 
              JOIN fastroute_f.clienti c ON s.email_cliente = c.email 
              WHERE s.cd_plico = :cd_plico";

    try {
        $stm = $db->prepare($query);
        $stm->bindValue(':cd_plico', $cd_plico);
        $stm->execute();
        $client = $stm->fetch();
        $stm->closeCursor();

        if (!$client) {
            return false;
        }
        $mail = new PHPMailer(true);
        $mail->SMTPDebug = 0;
        $mail->isSMTP();
        $mail->Host = 'smtp.gmail.com';
        $mail->SMTPAuth = true;
        $mail->Username = 'brian.rizzi@iisviolamarchesini.edu.it';
        $mail->Password = 'debl jjut brvs timh';
        $mail->SMTPSecure = PHPMailer::ENCRYPTION_STARTTLS;
        $mail->Port = 587;
        $mail->setFrom('brian.rizzi@iisviolamarchesini.edu.it');
        $mail->addAddress($client['email']);
        $mail->Subject = 'Notifica di ritiro plico - Artife';
        $mail->Body = "Gentile {$client['nome']} {$client['cognome']},\n\nIl suo plico con codice {$cd_plico} è stato ritirato dal destinatario.\n\nGrazie per aver scelto FastRoute.";
        $mail->CharSet = 'UTF-8';
        $mail->Encoding = 'base64';

        $mail->send();
        return true;

    } catch (Exception $e) {
        return false;
    }
}