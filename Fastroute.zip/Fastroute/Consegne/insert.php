<?php
$title = "Registra Consegne";

require '../Template/header.php';
require '../Plichi/update.php';
require_once '../Database/Db_connection.php';
$config = require '../Database/db_config.php';
$db = Db_connection::getDb($config);

$error_message = '';

if ($_SERVER["REQUEST_METHOD"] == "POST") {
    $email_personale = $_POST['email_personale'];
    $cd_plico = $_POST['cd_plico'];
    $data = $_POST['data'];

    $query = 'INSERT INTO fastroute_f.consegne(email_personale, cd_plico, data) VALUES (:email_personale, :cd_plico, :data)';

    try{
        $stm = $db->prepare($query);
        $stm->bindValue(':email_personale', $email_personale);
        $stm->bindValue(':cd_plico', $cd_plico);
        $stm->bindValue(':data', $data);
        $stm->execute();
        $stm->closeCursor();

        updateState($db, $cd_plico, 'In transito');

    } catch (Exception $e) {
        $error_message = "<div class='mx-5 my-5 alert alert-danger text-center'>Errore nella registrazione della consegna.</div>";
    }
}
?>
<div class="text-center pt-3">
    <h2 class="fw-bold text-uppercase text-shadow-lg pb-2">Registra una consegna</h2>
</div>
<?= $error_message; ?>
<div class="container my-4">
    <form method="post" action="insert.php">
        <div class="mb-3">
            <label for="email_personale" class="form-label">Email personale:</label>
            <input type="email" class="form-control" id="email_personale" name="email_personale" required>
        </div>
        <div class="mb-3">
            <label for="cd_plico" class="form-label">Codice plico:</label>
            <input type="number" class="form-control" id="cd_plico" name="cd_plico" required>
        </div>
        <div class="mb-3">
            <label for="data" class="form-label">Data:</label>
            <input type="datetime-local" class="form-control" id="data" name="data" required>
        </div>
        <div class="d-flex justify-content-end">
            <button type="submit" name="register" class="btn btn-primary">Registra</button>
        </div>
    </form>
</div>
<?php
require '../Template/footer.php';
?>
