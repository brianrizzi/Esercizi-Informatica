<?php
$error_message = '';
$consegne = [];

$query = 'SELECT * FROM fastroute_f.consegne ORDER BY data DESC';

try {
    $stm = $db->prepare($query);
    $stm->execute();
    $consegne = $stm->fetchAll();
    $stm->closeCursor();

} catch (Exception $e) {
    $error_message = "<div class='mx-5 my-5 alert alert-danger text-center'>Errore nella visualizzazione delle consegne.</div>";
}
?>
<div class="text-center pt-3">
    <h2 class="fw-bold text-uppercase text-shadow-lg pb-2">Consegne:</h2>
</div>
<?= $error_message ?>
<div class="mt-5 ms-5 me-5">
    <table class="table table-hover">
        <thead>
        <tr>
            <th class="col">Email_personale</th>
            <th class="col">Codice_plico</th>
            <th class="col">Data_consegna</th>
        </tr>
        </thead>
        <tbody class="table-group-divider">
        <?php
        foreach ($consegne as $consegna) {
            echo '<tr>';
            echo '<td>'.$consegna['email_personale']."</td>";
            echo '<td>'.$consegna['cd_plico']."</td>";
            echo '<td>'.($consegna['data'] ? $consegna['data'] : 'Non disponibile')."</td>";
            echo '</tr>';
        } ?>
        </tbody>
    </table>
</div>