<?php
$title = "Ricerca Consegne";

require '../Template/header.php';
require_once '../Database/Db_connection.php';
$config = require '../Database/db_config.php';
$db = Db_connection::getDb($config);

$error_message = '';
$total = 0;
$daily = [];

if ($_SERVER["REQUEST_METHOD"] == "POST") {
    $days = $_POST['days'];

        try {
            $query = 'SELECT DATE(data) as delivery_date, COUNT(*) as count 
                      FROM fastroute_f.consegne 
                      WHERE DATEDIFF(NOW(), data) <= :days
                      GROUP BY DATE(data) 
                      ORDER BY delivery_date DESC';

            $stm = $db->prepare($query);
            $stm->bindValue(':days', $days);
            $stm->execute();
            $daily = $stm->fetchAll();
            $stm->closeCursor();

            foreach ($daily as $day) {
                $total += $day['count'];
            }

        } catch (Exception $e) {
            $error_message = "<div class='mx-5 my-5 alert alert-danger text-center'>Errore nell'esecuzione della ricerca:</div>";
        }
}
?>
    <div class="text-center pt-3">
        <h2 class="fw-bold text-uppercase text-shadow-lg pb-2">Ricerca Consegne</h2>
    </div>
<?= $error_message; ?>
    <div class="container my-4">
        <form method="post" action="">
            <div class="mb-3">
                <label for="days" class="form-label">Numero di giorni da considerare:</label>
                <input type="number" class="form-control" id="days" name="days" min="1" required>
            </div>
            <div class="d-flex justify-content-end">
                <button type="submit" class="btn btn-primary">Cerca</button>
            </div>
        </form>
        <?php if ($_SERVER["REQUEST_METHOD"] == "POST"){ ?>
            <div class="mt-5">
                <div class="card mb-4">
                    <div class="card-header text-white">
                        <h4>Risultati della ricerca</h4>
                    </div>
                    <div class="card-body">
                        <h5>Numero totale di consegne negli ultimi <?= $days; ?> giorni:
                            <span><?= $total; ?></span>
                        </h5>
                    </div>
                </div>
                <?php if ($daily){ ?>
                    <div class="card">
                        <div class="card-header text-white">
                            <h4>Dettaglio consegne giornaliere</h4>
                        </div>
                        <div class="card-body">
                            <table class="table table-striped">
                                <thead>
                                <tr>
                                    <th>Data</th>
                                    <th>Numero di consegne</th>
                                </tr>
                                </thead>
                                <tbody>
                                <?php foreach ($daily as $day){ ?>
                                    <tr>
                                        <td><?= $day['delivery_date']; ?></td>
                                        <td><?= $day['count']; ?></td>
                                    </tr>
                                <?php } ?>
                                </tbody>
                            </table>
                        </div>
                    </div>
                <?php } else{ ?>
                    <div class="alert alert-info">Non ci sono consegne registrate nel periodo selezionato.</div>
                <?php } ?>
            </div>
        <?php } ?>
    </div>
<?php
require '../Template/footer.php';
?>