<?php
$title = "Gestione Completa Plichi";

require '../Template/header.php';
require_once '../Database/Db_connection.php';
$config = require '../Database/db_config.php';
$db = Db_connection::getDb($config);

require_once '../Spedizioni/read.php';
require_once '../Consegne/read.php';
require_once '../Ritiri/read.php';
require '../Template/footer.php';
