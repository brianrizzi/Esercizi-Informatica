<?php
$title = "Home";

require_once '../Template/header.php';
?>
    <div class="py-5">
        <div class="row mb-5">
            <div class="col-md-12">
                <div class="card shadow hero-card">
                    <div class="card-body p-5 text-center">
                        <h1 class="display-4 fw-bold mb-3">Benvenuti in FastRoute</h1>
                        <h4 class="mb-4">Il tuo partner affidabile per consegne rapide e sicure</h4>
                        <p class="lead mb-4">Offriamo servizi di corriere espresso per aziende e privati, garantendo puntualità, sicurezza e tracciabilità di ogni spedizione.</p>
                        <a href="#richiedi-info" class="btn btn-primary btn-lg px-4 py-2">Richiedi Informazioni</a>
                    </div>
                </div>
            </div>
        </div>
        <div class="row mb-5">
            <div class="col-md-12 mb-4">
                <h2 class="section-title text-center mb-4">I Nostri Servizi</h2>
                <hr class="section-divider mx-auto mb-5">
            </div>
            <div class="col-md-4 mb-4">
                <div class="card h-100 shadow-sm service-card">
                    <div class="card-body text-center p-4">
                        <i class='bx bx-package service-icon mb-3'></i>
                        <h4 class="mb-3">Spedizioni Express</h4>
                        <p>Consegne rapide in 24-48 ore su tutto il territorio nazionale.</p>
                        <a href="#" class="stretched-link"></a>
                    </div>
                </div>
            </div>
            <div class="col-md-4 mb-4">
                <div class="card h-100 shadow-sm service-card">
                    <div class="card-body text-center p-4">
                        <i class='bx bx-world service-icon mb-3'></i>
                        <h4 class="mb-3">Spedizioni Internazionali</h4>
                        <p>Servizio di spedizione verso più di 180 paesi nel mondo.</p>
                        <a href="#" class="stretched-link"></a>
                    </div>
                </div>
            </div>
            <div class="col-lg-3 col-md-6 mb-4">
                <div class="card h-100 shadow-sm service-card">
                    <div class="card-body text-center p-4">
                        <i class='bx bx-support service-icon mb-3'></i>
                        <h4 class="mb-3">Assistenza Clienti</h4>
                        <p>Supporto dedicato in orario lavorativo, per qualsiasi necessità relativa alle tue spedizioni.</p>
                        <a href="#" class="stretched-link"></a>
                    </div>
                </div>
            </div>
        <div class="row mb-5" id="richiedi-info">
            <div class="col-md-12 mb-4">
                <h2 class="section-title text-center mb-4">Richiedi Informazioni</h2>
                <hr class="section-divider mx-auto mb-5">
            </div>
            <div class="col-lg-8 col-md-10 mx-auto">
                <div class="card shadow contact-card">
                    <div class="card-body p-5">
                        <?php
                        $nome = $email = $messaggio = "";
                        $success = false;
                        $error_message = "";

                        require '../Mail/request.php';

                        if ($success){ ?>
                            <div class="alert alert-success d-flex align-items-center">
                                <i class='bx bx-check-circle fs-4 me-2'></i>
                                <div>La tua richiesta è stata inviata con successo! Ti risponderemo il prima possibile.</div>
                            </div>
                        <?php }
                        if (!empty($error_message)){ ?>
                            <div class="alert alert-danger d-flex align-items-center">
                                <i class='bx bx-error-circle fs-4 me-2'></i>
                                <div><?= $error_message; ?></div>
                            </div>
                        <?php } ?>
                        <form method="post" action="<?= $_SERVER["PHP_SELF"] . '#richiedi-info' ?>" class="needs-validation">
                            <div class="row">
                                <div class="col-md-6 mb-4">
                                    <label for="nome" class="form-label fw-bold">Nome:</label>
                                    <div class="input-group">
                                        <span class="input-group-text"><i class='bx bx-user'></i></span>
                                        <input type="text" class="form-control" id="nome" name="nome" value="<?= $nome ?>" required>
                                    </div>
                                </div>

                                <div class="col-md-6 mb-4">
                                    <label for="email" class="form-label fw-bold">Email:</label>
                                    <div class="input-group">
                                        <span class="input-group-text"><i class='bx bx-envelope'></i></span>
                                        <input type="email" class="form-control" id="email" name="email" value="<?= $email ?>" required>
                                    </div>
                                </div>
                            </div>

                            <div class="mb-4">
                                <label for="messaggio" class="form-label fw-bold">Messaggio:</label>
                                <div class="input-group">
                                    <span class="input-group-text"><i class='bx bx-message-detail'></i></span>
                                    <textarea class="form-control" id="messaggio" name="messaggio" rows="5" required><?= $messaggio ?></textarea>
                                </div>
                            </div>

                            <div class="text-center mt-4">
                                <button type="submit" class="btn btn-primary">
                                    <i class='bx bx-send me-2'></i> Invia Richiesta
                                </button>
                            </div>
                        </form>
                    </div>
                </div>
            </div>
        </div>
    </div>
<?php
require_once '../Template/footer.php';
?>
