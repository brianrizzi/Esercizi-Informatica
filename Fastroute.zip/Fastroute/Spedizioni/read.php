<?php
$error_message = '';
$spedizioni = [];

$query = 'SELECT * FROM fastroute_f.spedizioni ORDER BY data DESC';

try {
    $stm = $db->prepare($query);
    $stm->execute();
    $spedizioni = $stm->fetchAll();
    $stm->closeCursor();

} catch (Exception $e) {
    $error_message = "<div class='mx-5 my-5 alert alert-danger text-center'>Errore nella visualizzazione delle spedizioni.</div>";
}
?>
    <div class="text-center pt-3">
        <h2 class="fw-bold text-uppercase text-shadow-lg pb-2">Spedizioni:</h2>
    </div>
<?= $error_message ?>
    <div class="mt-5 ms-5 me-5">
        <table class="table table-hover">
            <thead>
            <tr>
                <th class="col">Email_cliente</th>
                <th class="col">Codice_plico</th>
                <th class="col">Data_spedizione</th>
            </tr>
            </thead>
            <tbody class="table-group-divider">
            <?php
            foreach ($spedizioni as $spedizione) {
                echo '<tr>';
                echo '<td>'.$spedizione['email_cliente']."</td>";
                echo '<td>'.$spedizione['cd_plico']."</td>";
                echo '<td>'.($spedizione['data'] ? $spedizione['data'] : 'Non disponibile')."</td>";
                echo '</tr>';
            } ?>
            </tbody>
        </table>
    </div>