<?php
$title = 'Inserisci Plico';

require '../Template/header.php';
require_once '../Database/Db_connection.php';
$config = require '../Database/db_config.php';
$db = Db_connection::getDb($config);

$error_message = '';

if ($_SERVER['REQUEST_METHOD'] == 'POST') {
    $codice = $_POST['codice'];

    $query = "INSERT INTO plichi (codice) VALUES (:codice)";

    try{
        $stm = $db->prepare($query);
        $stm->bindValue(':codice', $codice);
        $stm->execute();
        $stm->closeCursor();

    } catch(Exception $e){
        $error_message = "<div class='mx-5 my-5 alert alert-danger text-center'>Errore nell'inserimento del plico.</div>";
    }
}
?>
<div class="text-center pt-3">
    <h2 class="fw-bold text-uppercase text-shadow-lg pb-2">Inserisci un plico</h2>
</div>
<?= $error_message; ?>
<div class="container my-4">
    <form method="post" action="insert.php">
        <div class="mb-3">
            <label for="codice" class="form-label">Codice:</label>
            <input type="number" class="form-control" id="codice" name="codice" required>
        </div>
        <div class="d-flex justify-content-end">
            <button type="submit" name="register" class="btn btn-primary">Inserisci</button>
        </div>
    </form>
</div>
<?php
require '../Template/footer.php';
?>

