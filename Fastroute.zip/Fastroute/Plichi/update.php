<?php
function updateState($db, $cd_plico, $stato)
{
    try {
        $query = 'UPDATE fastroute_f.plichi SET stato = :stato WHERE codice = :cd_plico';
        $stm = $db->prepare($query);
        $stm->bindValue(':stato', $stato);
        $stm->bindValue(':cd_plico', $cd_plico);
        $stm->execute();

    } catch (Exception $e) {
        echo $e->getMessage();
        return false;
    }
}