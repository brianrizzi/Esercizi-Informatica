<?php
$title = 'Verifica Stato';

require '../Template/header.php';
require '../Database/Db_connection.php';
$config = require '../Database/db_config.php';
$db = Db_connection::getDb($config);

$error_message = '';
$result = null;
$searched = false;

if ($_SERVER["REQUEST_METHOD"] == "POST") {
    $codice = $_POST['codice'];
    $searched = true;

    try {
        $query = "SELECT codice, stato FROM fastroute_f.plichi WHERE codice = :codice";
        $stm = $db->prepare($query);
        $stm->bindValue(':codice', $codice);
        $stm->execute();
        $result = $stm->fetch();
        $stm->closeCursor();

    } catch (Exception $e) {
        $error_message = "<div class='mx-5 my-5 alert alert-danger text-center'>Si è verificato un errore durante la ricerca</div>";
    }
}
?>
    <div class="text-center pt-3">
        <h2 class="fw-bold text-uppercase text-shadow-lg pb-2">Verifica lo stato del plico</h2>
    </div>
<?= $error_message ?>
    <div class="container my-4">
        <form method="post" action="">
            <div class="mb-3">
                <label class="form-label" for="codice">Codice:</label>
                <input class="form-control" type="number" id="codice" name="codice" required>
            </div>
            <div class="d-flex justify-content-end">
                <button type="submit" class="btn btn-primary">Cerca</button>
            </div>
        </form>
        <?php if ($result){ ?>
            <div class="mt-5">
                <div class="card mb-4">
                    <div class="card-header text-white">
                        <h4>Risultati della ricerca</h4>
                    </div>
                    <div class="card-body">
                        <table class="table table-striped">
                            <thead>
                            <tr>
                                <th>Codice plico</th>
                                <th>Stato attuale</th>
                            </tr>
                            </thead>
                            <tbody>
                            <tr>
                                <td><?= $result['codice'] ?></td>
                                <td><?= $result['stato'] ?? 'Non definito' ?></td>
                            </tr>
                            </tbody>
                        </table>
                    </div>
                </div>
            </div>
        <?php } else if ($searched){ ?>
            <div class="alert alert-info mt-4">
                Nessun plico trovato con il codice specificato.
            </div>
        <?php } ?>
    </div>
<?php
require '../Template/footer.php';
?>