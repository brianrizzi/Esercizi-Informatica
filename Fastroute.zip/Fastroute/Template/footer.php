</div>
<div>
    <div class="footer">
        <p>&copy; 2025 FastRoute. Tutti i diritti riservati.</p>
    </div>
</div>
<script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/js/bootstrap.bundle.min.js"></script>
</body>
</html>

