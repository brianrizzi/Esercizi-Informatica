<?php
return [
    'default' => [
        'name' => 'Default',
        'navbar' => '#535a73',
        'title_bg' => '#3d4254'
    ],
    'blue' => [
        'name' => 'Blu',
        'navbar' => '#2c3e50',
        'title_bg' => '#1a2530'
    ],
    'green' => [
        'name' => 'Verde',
        'navbar' => '#2e7d32',
        'title_bg' => '#1b5e20'
    ],
    'purple' => [
        'name' => 'Viola',
        'navbar' => '#673ab7',
        'title_bg' => '#4527a0'
    ],
    'red' => [
        'name' => 'Rosso',
        'navbar' => '#c62828',
        'title_bg' => '#b71c1c'
    ],
    'yellow' => [
        'name' => 'Giallo',
        'navbar' => '#F9A825',
        'title_bg' => '#F57F17'
    ]
];
