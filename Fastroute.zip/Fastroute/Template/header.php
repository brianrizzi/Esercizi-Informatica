<!doctype html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport"
          content="width=device-width, user-scalable=no, initial-scale=1.0, maximum-scale=1.0, minimum-scale=1.0">
    <meta http-equiv="X-UA-Compatible" content="ie=edge">
    <link rel="icon" type="image/png" href="../Images/logo.png">
    <link href='https://unpkg.com/boxicons@2.1.4/css/boxicons.min.css' rel='stylesheet'>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/css/bootstrap.min.css" rel="stylesheet">
    <link href="https://getbootstrap.com/docs/5.3/assets/css/docs.css" rel="stylesheet">
    <link rel="stylesheet" href="../Style/style.css">
    <title>FastRoute - <?= /**@var $title*/ $title?></title>
    <?php
    if (session_status() == PHP_SESSION_NONE) {
        session_start();
    }
    $color_themes = require __DIR__ . '/color_themes.php';

    if (!isset($_SESSION['color_theme']) && isset($_COOKIE['user_theme'])) {
        $_SESSION['color_theme'] = $_COOKIE['user_theme'];

    } else if (!isset($_SESSION['color_theme'])) {
        $_SESSION['color_theme'] = 'default';
    }

    $current_theme = $_SESSION['color_theme'];
    $theme = isset($color_themes[$current_theme]) ? $color_themes[$current_theme] : $color_themes['default'];
    ?>
    <style>
        .navbar, .footer {
            background-color: <?= $theme['navbar'] ?>;
        }
        .div_title, .title-bg, .card-header {
            background-color: <?= $theme['title_bg'] ?>;
            color: white;
        }
        .btn-primary {
            background-color: <?= $theme['navbar'] ?>;
            border-color: <?= $theme['navbar'] ?>;
        }
        .dropdown-menu.topnav {
            background-color: <?= $theme['navbar'] ?>
        }
    </style>
</head>
<body class="d-flex flex-column min-vh-100">
<div class="container-fluid d-flex align-items-center py-3 px-4 div_title">
    <img src="../Images/logo.png" alt="Logo" height="50" class="me-3">
    <h4 class="mb-0 fw-bold title">FastRoute</h4>
</div>
<nav class="navbar navbar-expand-lg topnav">
    <div class="container-fluid">
        <button class="navbar-toggler" type="button" data-bs-toggle="collapse" data-bs-target="#navbarNavDropdown" aria-controls="navbarNavDropdown" aria-expanded="false" aria-label="Toggle navigation">
            <span class="navbar-toggler-icon"></span>
        </button>
        <div class="collapse navbar-collapse" id="navbarNavDropdown">
            <ul class="navbar-nav w-100">
                <li class="nav-item">
                    <a class="nav-link" href="../Home/index.php">Home</a>
                </li>
                <?php if(isset($_SESSION['user_email'])) { ?>
                <li class="nav-item dropdown">
                    <a class="nav-link dropdown-toggle" href="#" role="button" data-bs-toggle="dropdown" aria-expanded="false">
                        Plichi
                    </a>
                    <ul class="topnav dropdown-menu">
                        <li><a class="dropdown-item" href="../Plichi/insert.php">Inserisci</a></li>
                        <li><a class="dropdown-item" href="../Plichi/check.php">Controlla stato</a></li>
                    </ul>
                </li>
                <li class="nav-item">
                    <a class="nav-link" href="../Dashboard/dashboard.php">Dashboard</a>
                </li>
                <li class="nav-item">
                    <a class="nav-link" href="../Spedizioni/insert.php">Spedizioni</a>
                </li>
                <li class="nav-item dropdown">
                    <a class="nav-link dropdown-toggle" href="#" role="button" data-bs-toggle="dropdown" aria-expanded="false">
                        Consegne
                    </a>
                    <ul class="topnav dropdown-menu">
                        <li><a class="dropdown-item" href="../Consegne/insert.php">Inserisci</a></li>
                        <li><a class="dropdown-item" href="../Consegne/check.php">Consegne per giorni</a></li>
                    </ul>
                </li>
                <li class="nav-item">
                    <a class="nav-link" href="../Ritiri/insert.php">Ritiri</a>
                </li>
                <li class="nav-item">
                    <a class="nav-link" href="../Storico/read.php">Storico</a>
                </li>
                <li class="nav-item">
                    <a class="nav-link" href="../Staff/insert.php">Personale</a>
                </li>
                <li class="nav-item ms-lg-auto">
                        <div class="dropdown">
                            <a class="nav-link dropdown-toggle" href="#" role="button" data-bs-toggle="dropdown" aria-expanded="false">
                                <i class='bx bx-user-circle'></i> Ciao, <?= $_SESSION['user_nome'] ?>
                            </a>
                            <ul class="topnav dropdown-menu dropdown-menu-end">
                                <li><a class="dropdown-item logout-item" href="../Staff/info.php"><i class='bx bx-info-circle'></i> Informazioni</a></li>
                                <li><a class="dropdown-item logout-item" href="../Staff/logout.php"><i class='bx bx-log-out'></i> Logout</a></li>
                            </ul>
                        </div>
                    <?php  } else { ?>
                        <a class="nav-link ms-auto" href="../Staff/login.php"><i class='bx bx-log-in'></i>Login</a>
                    <?php } ?>
                </li>
            </ul>
        </div>
    </div>
</nav>
<div class="flex-grow-1">