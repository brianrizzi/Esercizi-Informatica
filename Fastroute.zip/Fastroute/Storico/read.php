<?php
$title = 'Storico';

require '../Template/header.php';
require '../Database/Db_connection.php';
$config = require '../Database/db_config.php';
$db = Db_connection::getDb($config);

$error_message = '';
$spedizioni = [];

try {
    $query = "SELECT 
                c.nome AS cliente_nome, 
                c.cognome AS cliente_cognome, 
                c.email AS cliente_email,
                d.nome AS destinatario_nome, 
                d.cognome AS destinatario_cognome, 
                d.email AS destinatario_email,
                p.codice AS codice_plico, 
                p.stato,
                s.data AS data_spedizione,
                con.data AS data_consegna,
                r.data AS data_ritiro,
                per.nome AS personale_nome,
                per.cognome AS personale_cognome,
                per.email AS personale_email,
                se.nome AS sede_nome
              FROM fastroute_f.plichi p
              LEFT JOIN fastroute_f.spedizioni s ON p.codice = s.cd_plico
              LEFT JOIN fastroute_f.clienti c ON s.email_cliente = c.email
              LEFT JOIN fastroute_f.consegne con ON p.codice = con.cd_plico
              LEFT JOIN fastroute_f.ritiri r ON p.codice = r.cd_plico
              LEFT JOIN fastroute_f.destinatari d ON r.email_destinatario = d.email
              LEFT JOIN fastroute_f.consegne cons ON p.codice = cons.cd_plico
              LEFT JOIN fastroute_f.personale per ON cons.email_personale = per.email
              LEFT JOIN fastroute_f.sedi se ON per.sede = se.nome
              ORDER BY s.data DESC";

    $stm = $db->prepare($query);
    $stm->execute();
    $spedizioni = $stm->fetchAll();
    $stm->closeCursor();

} catch (Exception $e) {
    $error_message = "<div class='mx-5 my-3 alert alert-danger text-center'>Errore durante il recupero delle spedizioni:</div>";
}
?>
    <div class="container-fluid">
        <div class="text-center pt-3">
            <h2 class="fw-bold text-uppercase text-shadow-lg pb-2">Storico Spedizioni:</h2>
        </div>
        <?= $error_message ?>
        <div class="mt-5 ms-5 me-5">
            <table class="table table-hover">
                <thead>
                <tr>
                    <th class="col">Cliente</th>
                    <th class="col">Destinatario</th>
                    <th class="col">Codice Plico</th>
                    <th class="col">Stato</th>
                    <th class="col">Data Spedizione</th>
                    <th class="col">Data Consegna</th>
                    <th class="col">Data Ritiro</th>
                    <th class="col">Personale</th>
                    <th class="col">Sede</th>
                </tr>
                </thead>
                <tbody class="table-group-divider">
                <?php
                foreach ($spedizioni as $spedizione) {
                    echo '<tr>';
                    echo '<td>'.($spedizione['cliente_nome'] ? $spedizione['cliente_nome'].' '.$spedizione['cliente_cognome'].'<br><small>'.$spedizione['cliente_email'].'</small>' : 'Non assegnato').'</td>';
                    echo '<td>'.($spedizione['destinatario_nome'] ? $spedizione['destinatario_nome'].' '.$spedizione['destinatario_cognome'].'<br><small>'.$spedizione['destinatario_email'].'</small>' : 'Non Assegnato').'</td>';
                    echo '<td>'.$spedizione['codice_plico'].'</td>';
                    echo '<td>'.($spedizione['stato'] ? $spedizione['stato'] : 'Non disponibile').'</td>';
                    echo '<td>'.($spedizione['data_spedizione'] ? $spedizione['data_spedizione'] : 'Non disponibile').'</td>';
                    echo '<td>'.($spedizione['data_consegna'] ? $spedizione['data_consegna'] : 'Non disponibile').'</td>';
                    echo '<td>'.($spedizione['data_ritiro'] ? $spedizione['data_ritiro'] : 'Non disponibile').'</td>';
                    echo '<td>'.($spedizione['personale_nome'] ? $spedizione['personale_nome'].' '.$spedizione['personale_cognome'].'<br><small>'.$spedizione['personale_email'].'</small>' : 'Non assegnato').'</td>';
                    echo '<td>'.($spedizione['sede_nome'] ? $spedizione['sede_nome'] : 'Non disponibile').'</td>';
                    echo '</tr>';
                }
                ?>
                </tbody>
            </table>
        </div>
    </div>

<?php
require '../Template/footer.php';
?>