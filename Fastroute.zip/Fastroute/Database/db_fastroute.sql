create database fastroute_f;

create table fastroute_f.clienti(
nome varchar(50) not null,
cognome varchar(50) not null,
indirizzo varchar(50) not null,
email varchar(50) primary key,
punteggio int default 0
);

create table fastroute_f.plichi(
codice int primary key,
stato varchar(50) default null,
foreign key (stato) references stati(titolo)
);

create table fastroute_f.stati(
titolo varchar(50) primary key
);

create table fastroute_f.sedi(
nome varchar(50) primary key,
citta varchar(50) not null
);

create table fastroute_f.personale(
    nome varchar(50) not null,
    cognome varchar(50) not null,
    pwd varchar(255) not null,
    email varchar(50) primary key,
    sede varchar(50),
    foreign key (sede) references sedi(nome)
);

create table fastroute_f.consegne(
email_personale varchar(50),
cd_plico int,
primary key (email_personale, cd_plico),
foreign key (email_personale) references personale(email),
foreign key (cd_plico) references plichi(codice),
data datetime
);

create table fastroute_f.destinatari(
nome varchar(50) not null,
cognome varchar(50) not null,
indirizzo varchar(50) not null,
email varchar(50) primary key
);

create table fastroute_f.spedizioni(
email_cliente varchar(50),
cd_plico int,
primary key(email_cliente, cd_plico),
foreign key (email_cliente) references clienti(email),
foreign key (cd_plico) references plichi(codice),
data datetime
);

create table fastroute_f.ritiri(
email_destinatario varchar(50),
cd_plico int,
primary key(email_destinatario, cd_plico),
foreign key (email_destinatario) references destinatari(email),
foreign key (cd_plico) references plichi(codice),
data datetime
);

insert into fastroute_f.stati (titolo) values
('In partenza'),
('In transito'),
('Consegnato');

INSERT INTO fastroute_f.clienti (nome, cognome, indirizzo, email) VALUES
('Marco', 'Rossi', 'Via Roma 123, Milano', 'marco.rossi@email.com'),
('Giulia', 'Bianchi', 'Corso Italia 45, Roma', 'giulia.bianchi@email.com'),
('Alessandro', 'Verdi', 'Viale Europa 67, Napoli', 'alessandro.verdi@email.com');

INSERT INTO fastroute_f.destinatari (nome, cognome, indirizzo, email) VALUES
('Laura', 'Ferrari', 'Via Dante 89, Torino', 'laura.ferrari@email.com'),
('Roberto', 'Marino', 'Piazza Garibaldi 12, Firenze', 'roberto.marino@email.com'),
('Francesca', 'Esposito', 'Corso Vittorio 34, Bologna', 'francesca.esposito@email.com'),
('Davide', 'Conti', 'Via Mazzini 56, Genova', 'davide.conti@email.com'),
('Chiara', 'Romano', 'Largo Marconi 23, Palermo', 'chiara.romano@email.com');

INSERT INTO fastroute_f.sedi (nome, citta) VALUES
('Sede Nord', 'Milano'),
('Sede Centro', 'Roma'),
('Sede Sud', 'Napoli'),
('Sede Est', 'Bologna'),
('Sede Ovest', 'Torino'),
('Sede Sicilia', 'Palermo'),
('Sede Sardegna', 'Cagliari');
