<?php
$title = 'Login Personale';

require '../Template/header.php';
require_once '../Database/Db_connection.php';
$config = require '../Database/db_config.php';
$db = Db_connection::getDb($config);

$error_message = '';

if ($_SERVER['REQUEST_METHOD'] == 'POST') {
    $email = $_POST['email'];
    $password = $_POST['password'];
    $remember = isset($_POST['remember']) ? true : false;

    $query = "SELECT * FROM personale WHERE email = :email";

    try {
        $stm = $db->prepare($query);
        $stm->bindValue(':email', $email);
        $stm->execute();
        $user = $stm->fetch();
        $stm->closeCursor();

        if($user && password_verify($password, $user['pwd'])) {
            if (session_status() == PHP_SESSION_NONE) {
                session_start();
            }
            $_SESSION['user_email'] = $user['email'];
            $_SESSION['user_nome'] = $user['nome'];
            $_SESSION['user_sede'] = $user['sede'];

            if($remember) {
                setcookie('email', $email, time() + (86400 * 30), "/");
                setcookie('password', $password, time() + (86400 * 30), "/");
            }

            header('Location: ../Home/index.php');
            exit;
        } else {
            $error_message = "<div class='mx-5 my-5 alert alert-danger text-center'>Email o password non validi.</div>";
        }
    } catch(Exception $e) {
        $error_message = "<div class='mx-5 my-5 alert alert-danger text-center'>Errore durante l'accesso.</div>";
    }
}
?>
    <div class="text-center pt-3">
        <h2 class="fw-bold text-uppercase text-shadow-lg pb-2">Accesso Personale</h2>
    </div>
<?= $error_message; ?>
    <div class="container my-4">
        <form method="post" action="login.php">
            <div class="mb-3">
                <label for="email" class="form-label">Email:</label>
                <input type="email" class="form-control" id="email" name="email" required>
            </div>
            <div class="mb-3">
                <label for="password" class="form-label">Password:</label>
                <input type="password" class="form-control" id="password" name="password" required>
            </div>
            <div class="mb-3 form-check">
                <input type="checkbox" class="form-check-input" id="remember" name="remember">
                <label class="form-check-label" for="remember">Ricorda le credenziali</label>
            </div>
            <div class="d-flex justify-content-end">
                <button type="submit" class="btn btn-primary">Accedi</button>
            </div>
        </form>
    </div>
<?php
require '../Template/footer.php';
?>