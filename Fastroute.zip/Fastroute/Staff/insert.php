<?php
$title = 'Inserisci Personale';

require '../Template/header.php';
require_once '../Database/Db_connection.php';
$config = require '../Database/db_config.php';
$db = Db_connection::getDb($config);

$error_message = '';

$query = 'SELECT * FROM fastroute_f.sedi';
$sedi = [];

try{
    $stm = $db->prepare($query);
    $stm->execute();
    $sedi = $stm->fetchAll();
    $stm->closeCursor();

}catch (Exception $e){
    echo $e->getMessage();
}

if ($_SERVER['REQUEST_METHOD'] == 'POST') {
    $nome = $_POST['nome'];
    $cognome = $_POST['cognome'];
    $pwd = $_POST['pwd'];
    $email = $_POST['email'];
    $sede = $_POST['sede'];

    $hashed_pwd = password_hash($pwd, PASSWORD_DEFAULT);

    $query = "INSERT INTO fastroute_f.personale (nome, cognome, pwd, email, sede) VALUES (:nome, :cognome, :pwd, :email, :sede)";

    try{
        $stm = $db->prepare($query);
        $stm->bindValue(':nome', $nome);
        $stm->bindValue(':cognome', $cognome);
        $stm->bindValue(':pwd', $hashed_pwd);
        $stm->bindValue(':email', $email);
        $stm->bindValue(':sede', $sede);
        $stm->execute();
        $stm->closeCursor();

    } catch(Exception $e){
        $error_message = "<div class='mx-5 my-5 alert alert-danger text-center'>Errore nell'inserimento del personale.</div>";
    }
}
?>
<div class="text-center pt-3">
    <h2 class="fw-bold text-uppercase text-shadow-lg pb-2">Inserisci un membro del personale</h2>
</div>
<?php echo $error_message; ?>
<div class="container my-4">
    <form method="post" action="insert.php">
        <div class="mb-3">
            <label for="nome" class="form-label">Nome:</label>
            <input type="text" class="form-control" id="nome" name="nome" required>
        </div>
        <form method="post" action="insert.php">
            <div class="mb-3">
                <label for="cognome" class="form-label">Cognome:</label>
                <input type="text" class="form-control" id="cognome" name="cognome" required>
            </div>
        <div class="mb-3">
            <label for="pwd" class="form-label">Password:</label>
            <input type="password" class="form-control" id="pwd" name="pwd" required>
        </div>
        <div class="mb-3">
            <label for="email" class="form-label">Email:</label>
            <input type="email" class="form-control" id="email" name="email" required>
        </div>
        <div class="mb-3">
            <label for="sede" class="form-label">Sede:</label>
            <select class="form-select" id="sede" name="sede" required>
                <?php foreach ($sedi as $s){ ?>
                    <option value="<?= $s['nome'] ?>">
                        <?= $s['nome'] ?>
                    </option>
                <?php } ?>
            </select>
        </div>
        <div class="d-flex justify-content-end">
            <button type="submit" name="register" class="btn btn-primary">Inserisci</button>
        </div>
    </form>
</div>
<?php
require '../Template/footer.php';
?>
