<?php
$title = 'Informazioni Personale';

require '../Template/header.php';
require_once '../Database/Db_connection.php';
$config = require '../Database/db_config.php';
$db = Db_connection::getDb($config);

$email = $_SESSION['user_email'];

$success_message = '';
$error_message = '';

try {
    $query = "SELECT * FROM personale WHERE email = :email";
    $stm = $db->prepare($query);
    $stm->bindValue(':email', $email);
    $stm->execute();
    $user = $stm->fetch();
    $stm->closeCursor();

} catch(Exception $e) {
    $error_message = "<div class='mx-5 my-3 alert alert-danger text-center'>Errore nel recupero delle informazioni.</div>";
}

if (isset($_POST['update_theme'])) {
    $selectedTheme = $_POST['color_theme'];
    $_SESSION['color_theme'] = $selectedTheme;

    $success_message = "<div class='mx-5 my-3 alert alert-success text-center'>Tema colore aggiornato con successo.</div>";
}

if (isset($_POST['update_password'])) {
    $currentPwd = $_POST['currentPwd'];
    $newPwd = $_POST['newPwd'];
    $confirmPwd = $_POST['confirmPwd'];

    if ($new_password !== $confirm_password) {
        $error_message = "<div class='mx-5 my-3 alert alert-danger text-center'>Le nuove password non corrispondono.</div>";
    } else {
        try {
            $query = "SELECT pwd FROM personale WHERE email = :email";
            $stm = $db->prepare($query);
            $stm->bindValue(':email', $email);
            $stm->execute();
            $user_data = $stm->fetch();
            $stm->closeCursor();

            if ($user_data && password_verify($currentPwd, $user_data['pwd'])) {
                $hashed_password = password_hash($newPwd, PASSWORD_DEFAULT);
                $query = "UPDATE personale SET pwd = :pwd WHERE email = :email";
                $stm = $db->prepare($query);
                $stm->bindValue(':pwd', $hashed_password);
                $stm->bindValue(':email', $email);
                $stm->execute();
                $stm->closeCursor();

                $success_message = "<div class='mx-5 my-3 alert alert-success text-center'>Password aggiornata con successo.</div>";
            } else {
                $error_message = "<div class='mx-5 my-3 alert alert-danger text-center'>La password attuale non è corretta.</div>";
            }
        } catch(Exception $e) {
            $error_message = "<div class='mx-5 my-3 alert alert-danger text-center'>Errore nell'aggiornamento della password.</div>";
        }
    }
}
$color_themes = require '../Template/color_themes.php';
$current_theme = isset($_SESSION['color_theme']) ? $_SESSION['color_theme'] : 'default';
?>
    <div class="text-center pt-3">
        <h2 class="fw-bold text-uppercase text-shadow-lg pb-2">Informazioni Personale</h2>
    </div>
<?= $success_message; ?>
<?= $error_message; ?>
    <div class="container my-4">
        <div class="row mb-4">
            <div class="col-md-12">
                <div class="card">
                    <div class="card-header">
                        <h5 class="card-title mb-0 info">Informazioni Personali</h5>
                    </div>
                    <div class="card-body">
                        <?php if ($user){ ?>
                            <div class="row">
                                <div class="col-md-6">
                                    <p><strong>Nome:</strong> <?= $user['nome'] ?></p>
                                    <p><strong>Cognome:</strong> <?= $user['cognome'] ?></p>
                                </div>
                                <div class="col-md-6">
                                    <p><strong>Email:</strong> <?= $user['email'] ?></p>
                                    <p><strong>Sede:</strong> <?= $user['sede'] ?></p>
                                </div>
                            </div>
                        <?php } else{ ?>
                            <div class="alert alert-warning">Nessuna informazione disponibile. Assicurati di aver effettuato l'accesso correttamente.</div>
                        <?php } ?>
                    </div>
                </div>
            </div>
        </div>
        <div class="row">
            <?php if ($user){ ?>
                <div class="col-md-6 mb-4">
                    <div class="card">
                        <div class="card-header">
                            <h5 class="card-title mb-0 info">Modifica Password</h5>
                        </div>
                        <div class="card-body">
                            <form method="post" action="info.php">
                                <div class="mb-3">
                                    <label for="$currentPwd" class="form-label">Password Attuale:</label>
                                    <input type="password" class="form-control" id="$currentPwd" name="$currentPwd" required>
                                </div>
                                <div class="mb-3">
                                    <label for="$newPwd" class="form-label">Nuova Password:</label>
                                    <input type="password" class="form-control" id="$newPwd" name="$newPwd" required>
                                </div>
                                <div class="mb-3">
                                    <label for="$confirmPwd" class="form-label">Conferma Nuova Password:</label>
                                    <input type="password" class="form-control" id="$confirmPwd" name="$confirmPwd" required>
                                </div>
                                <div class="d-flex justify-content-end">
                                    <button type="submit" name="update_password" class="btn btn-primary">Aggiorna Password</button>
                                </div>
                            </form>
                        </div>
                    </div>
                </div>
            <?php } ?>
            <div class="col-md-6 mb-4">
                <div class="card">
                    <div class="card-header">
                        <h5 class="card-title mb-0 info">Personalizzazione Interfaccia</h5>
                    </div>
                    <div class="card-body">
                        <form method="post" action="info.php">
                            <div class="mb-3">
                                <label for="color_theme" class="form-label">Tema Colore:</label>
                                <select class="form-select" id="color_theme" name="color_theme">
                                    <?php foreach ($color_themes as $key => $theme){ ?>
                                        <option value="<?= $key ?>" <?= $current_theme == $key && 'selected' ?>>
                                            <?= $theme['name'] ?>
                                        </option>
                                    <?php } ?>
                                </select>
                            </div>
                            <div class="d-flex justify-content-end">
                                <button type="submit" name="update_theme" class="btn btn-primary">Aggiorna Tema</button>
                            </div>
                        </form>
                    </div>
                </div>
            </div>
        </div>
    </div>
<?php
require '../Template/footer.php';
?>